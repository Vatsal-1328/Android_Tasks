package com.example.demo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;

public class actttttt extends MainActivity {
public static final String pname="Myprefsfile";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences settings = getSharedPreferences(pname,0);
        boolean dailogshown = settings.getBoolean("dailog.shown",false);
        if (!dailogshown){
           SharedPreferences.Editor editor= settings.edit();
           editor.putBoolean("dailogshown",true);
           editor.commit();
        }
       // setContentView(R.layout.activity_actttttt);
    }
}