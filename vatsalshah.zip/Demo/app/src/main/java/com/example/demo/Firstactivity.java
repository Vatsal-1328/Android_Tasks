package com.example.demo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.google.android.material.snackbar.Snackbar;

public class Firstactivity extends AppCompatActivity {
    Button displaybtn;
    LinearLayout l1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firstactivity);
        setTitle("first activity");

        displaybtn=(Button) findViewById(R.id.displaybutton);
        l1=(LinearLayout) findViewById(R.id.linearlayout1);



        displaybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar snackbar=Snackbar.make(l1,"Button Clicked",Snackbar.LENGTH_INDEFINITE);
                snackbar.setAction("Cancel",new View.OnClickListener(){
                    public void onClick(View view){
                        Snackbar snackbar=Snackbar.make(l1,"Welcome Back",Snackbar.LENGTH_SHORT);
                        snackbar.show();
                    }

                });
                snackbar.show();
            }
        });

    }
}