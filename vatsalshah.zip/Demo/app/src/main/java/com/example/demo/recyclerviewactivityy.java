//package com.example.demo;
//
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//
//import android.os.Bundle;
//import android.widget.LinearLayout;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//
//public class recyclerviewactivityy extends AppCompatActivity {
//
//    ArrayList pname = new ArrayList<>(Arrays.asList("p1","p2","p3","p4","p5","p6"));
//
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_recyclerviewactivityy);
//
//        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerview);
//        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
//        recyclerView.setLayoutManager(linearLayoutManager);
//        CustomAdapter customAdapter = new CustomAdapter(recyclerviewactivityy.this,pname);
//        recyclerView.setAdapter(customAdapter);
//
//    }
//}