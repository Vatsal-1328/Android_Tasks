package com.example.demo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "LogActivities";
    Button mainbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG,"OnCreate Method Called");
       // Toast.makeText(this,"OnCreate method called",Toast.LENGTH_LONG).show();
        init();

        mainbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i =new Intent(MainActivity.this,Firstactivity.class);
                i.putExtra("Name","Vatsal Shah");
                i.putExtra("Mobno","6353734602");
                startActivity((i));
                showdialog();

            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG,"OnStart Method Called");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG,"OnStop Method Called");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG,"OnDestroy Method Called");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG,"OnPause Method Called");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG,"OnResume Method Called");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG,"OnRestart Method Called");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.searchicon:
                Toast.makeText(getApplicationContext(),"search menu selected",Toast.LENGTH_LONG).show();
                break;
            case R.id.play:
                Toast.makeText(getApplicationContext(),"search menu selected",Toast.LENGTH_LONG).show();
                break;
            case R.id.pause:
                Toast.makeText(getApplicationContext(),"search menu selected",Toast.LENGTH_LONG).show();
                break;
            case R.id.signal:
                Toast.makeText(getApplicationContext(),"search menu selected",Toast.LENGTH_LONG).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        AlertDialog.Builder dailog= new AlertDialog.Builder(this);
        dailog.setTitle("Confirm exit");
        dailog.setIcon(R.drawable.ic_baseline_settings_24);
        dailog.setMessage("r u sure you want to exit?");
        dailog.setPositiveButton("yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });
        dailog.setNegativeButton("no", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(getApplicationContext(),"welcome back",Toast.LENGTH_LONG).show();
            }
        });

    }
    private void showdialog(){
        Dialog dialog= new Dialog(this);
        dialog.setContentView((R.layout.customdailog));
        Button btn=(Button) findViewById(R.id.btn);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
    }

    void init(){

    }
}