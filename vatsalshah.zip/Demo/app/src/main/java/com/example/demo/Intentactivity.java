package com.example.demo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

public class Intentactivity extends AppCompatActivity {
    Button implicit,implicit1,phn,email;
    ImageButton img;
    EditText text1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intentactivity);
        setTitle("Intent page");

        implicit=(Button) findViewById(R.id.implicit);
        implicit1=(Button) findViewById(R.id.explicit);
        img=(ImageButton) findViewById(R.id.imageButton);
        text1=(EditText) findViewById(R.id.text1) ;
        phn=(Button)findViewById(R.id.phn);
        email=(Button)findViewById(R.id.email);

        implicit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("http://www.google.com"));
                startActivity(intent);

                //MANNU IS Beautifull! BEWARE!!!!
            }
        });

        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // String text = "Hello......";
                String text = text1.getText().toString();
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT,text);
                i.setPackage("com.whatsapp");
                startActivity(Intent.createChooser(i,"bhajo bhajo"));
                text1.setText("");
            }
        });
        phn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:7780800161"));
                startActivity(intent);
            }
        });
        email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String subject = "Regarding Leave Application";
                String body = "Dear sir, Kindly approve my leave application";
                String recipients = "ap7916237@gmail.com";
                Intent email = new Intent(Intent.ACTION_SEND,Uri.parse("mailto:"));
                email.setType("message/rfc822");
                email.putExtra(Intent.EXTRA_EMAIL,recipients);
                email.putExtra(Intent.EXTRA_SUBJECT,subject);
                email.putExtra(Intent.EXTRA_TEXT,body);
                startActivity(Intent.createChooser(email,"Choose an email client from..."));
            }
        });

    }
}